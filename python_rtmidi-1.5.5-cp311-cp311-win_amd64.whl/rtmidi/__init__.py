"""A binding for the RtMidi C++ library."""

from .version import version as __version__  # noqa
from ._rtmidi import *  # noqa
from ._rtmidi import __doc__  # noqa
